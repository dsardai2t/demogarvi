
## Module <project_dashboard_odoo>

#### 26.05.2022
#### Version 15.0.1.0.0
## Module <project_dashboard_odoo>

##### Initial Commit for project_dashboard_odoo
